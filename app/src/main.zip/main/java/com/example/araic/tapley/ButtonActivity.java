package com.example.araic.tapley;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;


public class ButtonActivity extends ActionBarActivity {

    TextView imageClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);

        ImageView[][] images = new ImageView[8][8];



        final ImageView img1 = (ImageView) findViewById(R.id.imageView1);
        final ImageView img2 = (ImageView) findViewById(R.id.imageView2);
        final ImageView img3 = (ImageView) findViewById(R.id.imageView3);
        final ImageView img4 = (ImageView) findViewById(R.id.imageView4);
        final ImageView img5 = (ImageView) findViewById(R.id.imageView5);
        final ImageView img6 = (ImageView) findViewById(R.id.imageView6);
        final ImageView img7 = (ImageView) findViewById(R.id.imageView7);
        final ImageView img8 = (ImageView) findViewById(R.id.imageView8);
        final ImageView[] imageViews = {img1,img2,img3,img4,img5,img5,img6,img7,img8};

        imageClicked = (TextView) findViewById(R.id.imageClicked);
        for(int i = 0; i < imageViews.length; i++)
            img1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imageClicked.setText("Index of image: " + Arrays.asList(imageViews).indexOf(img1));
                }
            });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_button, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
