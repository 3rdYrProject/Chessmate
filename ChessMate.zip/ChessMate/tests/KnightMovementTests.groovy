package com.chessmate

import org.junit.Before
import org.junit.Test

/**
 * Created by sgib0001 on 15/03/15.
 */
class KnightMovementTests {
    Tile[][] tileMap = new Tile[8][8]
    AI ai= new AI()
    Knight userKnight
    Knight aiKnight= new Knight(6,2,1,0)
    @Before
    void setup(){
        def intMap =[
                [1,1,1,1,1,1,1,1],
                [1,1,0,1,0,1,1,1],
                [1,4,2,1,1,1,1,1],
                [1,1,1,1,3,1,1,1],
                [1,1,1,4,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1]
        ]
        intMap.eachWithIndex { def entry, int i ->
            entry.eachWithIndex { int num, int j ->
                if(num==4)
                {
                    tileMap[i][j]= new Rook(i,j,num,0)
                    ai.addPiece(new Rook(i,j,num,0))
                }
                else if(num==2)
                {
                    userKnight= new Knight(i,j,num,1)
                    tileMap[i][j]= userKnight
                }
                else
                    tileMap[i][j]= new Tile(i,j,num)

            }
            println()

        }


    }
    @Test
    void moveToValidSquare() {
        def actual= userKnight.move(tileMap[0][1],tileMap,ai)
        tileMap[0][1]=userKnight
        assert(actual == tileMap)
    }

    @Test
    void moveToInvalidSquare() {
        def actual= userKnight.move(tileMap[2][5],tileMap,ai)
        assert(actual == tileMap)
    }

    @Test
    void moveToObstacleSquare() {
        def actual= userKnight.move(tileMap[1][4],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void moveThroughObstacleSquare() {
        def actual= userKnight.move(tileMap[0][3],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void moveToGoal()
    {
        def actual= userKnight.move(tileMap[3][4],tileMap,ai)
        tileMap[3][4]=
    }
    @Test
    void takePiece() {
        def actual =userKnight.move(tileMap[4][3],tileMap,ai)
        tileMap[userKnight.x][userKnight.y]=new Tile(userKnight.x,userKnight.y,1)
        tileMap[4][3]=userKnight
        assert(ai.aiPieces.size()==1&&tileMap==actual)
    }
    @Test
    void takeFriendlyPiece(){
        def actual =aiKnight.move(tileMap[4][3],tileMap,ai)
        assert(!ai.isEmpty()&&actual==tileMap)
    }
    @Test
    void movePastPiece(){

        println()
        userKnight.move(tileMap[3][0],tileMap,ai)
        assert(tileMap[3][0].equals(userKnight))
    }

}
