package com.chessmate;
import org.junit.Before
import org.junit.Test

/**
 * Created by sgib0001 on 06/03/15.
 */
class BishopMovementTests {

    Tile[][] tileMap = new Tile[8][8]
    AI ai= new AI()
    Bishop userBishop
    Bishop aiBishop= new Bishop(6,2,1,0)
    @Before
    void setup(){
        def intMap =[
                [1,1,1,1,1,1,1,1],
                [1,1,1,0,1,1,1,1],
                [1,1,2,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,4,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1]
        ]
        intMap.eachWithIndex { def entry, int i ->
            entry.eachWithIndex { int num, int j ->
                if(num==4)
                {
                    tileMap[i][j]= new Rook(i,j,num,0)
                    ai.addPiece(new Rook(i,j,num,0))
                }
                else if(num==2)
                {
                    userBishop= new Bishop(i,j,num,1)
                    tileMap[i][j]= userBishop
                }
                else
                    tileMap[i][j]= new Tile(i,j,num)

            }
            println()

        }


    }
    @Test
    void moveToValidSquare() {
        def actual= userBishop.move(tileMap[0][0],tileMap,ai)
        tileMap[0][0]=userBishop
        assert(actual == tileMap)
    }

    @Test
    void moveToInvalidSquare() {
        def actual= userBishop.move(tileMap[1][5],tileMap,ai)
        assert(actual == tileMap)
    }

    @Test
    void moveToObstacleSquare() {
        def actual= userBishop.move(tileMap[1][3],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void moveThroughObstacleSquare() {
        def actual= userBishop.move(tileMap[0][4],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void takePiece() {
        def actual =userBishop.move(tileMap[4][4],tileMap,ai)
        tileMap[userBishop.x][userBishop.y]=new Tile(userBishop.x,userBishop.y,1)
        tileMap[4][4]=userBishop
        assert(ai.isEmpty()&&tileMap==actual)
    }
    @Test
    void takeFriendlyPiece(){
        def actual =aiBishop.move(tileMap[4][4],tileMap,ai)
        assert(!ai.isEmpty()&&actual==tileMap)
    }
    @Test
    void movePastPiece(){

        println()
        userBishop.move(tileMap[5][5],tileMap,ai)
        println(tileMap[4][4].getOccupied())
        assert(ai.isEmpty()&&tileMap[4][4].equals(userBishop))
    }

}
