package com.chessmate;
import org.junit.Before
import org.junit.Test

class RookMovementTests
{
    Tile[][] tileMap = new Tile[8][8]
    AI ai= new AI()
    Rook userRook= new Rook(0,0,1,1)
    Rook aiRook= new Rook(4,4,1,0)

    /**
     * @Debug
     *
     *tileMap.each{
     *   it.each{
     *       print(it.type)
     *   }
     *   println()
     *}
     *
     */
    @Before
    void setup(){
        def intMap =[
                [2,1,1,1,1,1,0,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [4,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1],
                [1,1,1,1,1,1,1,1]
        ]
        intMap.eachWithIndex { def entry, int i ->
            entry.eachWithIndex { int num, int j ->

                if(num==4)
                {
                    tileMap[i][j]= new Rook(i,j,num,0)
                    ai.addPiece(new Rook(i,j,num,0))
                }
                else if(num==2)
                {
                    tileMap[i][j]= new Rook(i,j,num,0)
                }
                else
                    tileMap[i][j]= new Tile(i,j,num)

            }
            println()
        }


    }
    @Test
    void moveToValidSquare() {

        def actual= userRook.move(tileMap[0][5],tileMap,ai)
        tileMap[0][5]=userRook
        assert(actual == tileMap)
    }

    @Test
    void moveToInvalidSquare() {
        def actual= userRook.move(tileMap[1][5],tileMap,ai)
        assert(actual == tileMap)
    }

    @Test
    void moveToObstacleSquare() {
        def actual= userRook.move(tileMap[0][6],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void moveThroughObstacleSquare() {
        def actual= userRook.move(tileMap[0][7],tileMap,ai)
        assert(actual == tileMap)
    }
    @Test
    void takePiece() {
        userRook.move(tileMap[4][0],tileMap,ai)
        assert(ai.isEmpty())
    }
    @Test
    void takeFriendlyPiece(){
        def actual =aiRook.move(tileMap[4][0],tileMap,ai)
        assert(!ai.isEmpty()&&actual==tileMap)
    }
    @Test
    void movePastPiece(){

        println()
        def actual =userRook.move(tileMap[7][0],tileMap,ai)
        assert(ai.isEmpty())
    }
    @Test
    void moveSelf()
    {
        def actual= userRook.move(userRook,tileMap,ai)
        assert(actual=tileMap)
    }
}