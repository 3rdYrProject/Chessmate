package chessmate;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Created by araic on 05/03/15.
 */

class Rook extends Piece
{
    int x,y;
    BufferedImage BRook;
    BufferedImage WRook;
    Rook(int x, int y, int type, int color)
    {
        super(x,y,type,"Rook",color);
        this.x = x;
        this.y = y;
        this.color=color;
        try {
            if(color==0) {
                File file = new File(System.getProperty("user.dir")+"/resources/drawable/blackrook.png");
                BRook = ImageIO.read(file);
            }
            else {
                File file = new File(System.getProperty("user.dir")+"/resources/drawable/whiterook.png");
                WRook = ImageIO.read(file);
            }
        }catch(Exception e){}
    }

    public Tile[][] move(Tile t, Tile[][] tiles,AI ai)
    {
        if(t==null)
            return tiles;
        if(t.getType()==0)
            return tiles;
        int dir = checkOrth(t);
        Tile temp;
        //p("dir: " + dir);
        if(dir > 0){//if on a direction allow move
            //method to create a list of tiles between current and goal

            //need to check each square in route to see if AI piece or obstacle
            temp = checkRoute(t,dir,tiles);
            //System.out.println("in rook move " + temp);

            if(temp!=null)
            {
                tiles=(super.move(temp,tiles,ai));
            }
        }
        return tiles;
    }
    void p(String s) {
        System.out.println(s);
    }

    public int checkOrth(Tile goal){
        //System.out.println("in orth: " + goal);
        return super.checkOrth(goal);
    }

    public Tile checkRoute(Tile goal, int direction, Tile[][] tiles){
        return super.checkRoute(goal, direction, tiles);
    }
    public void draw(Graphics g, int i)
    {
        super.draw(g,i,BRook,WRook,color);
    }
}
