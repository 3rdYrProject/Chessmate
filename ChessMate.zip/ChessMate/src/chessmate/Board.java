package chessmate;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.*;
import java.io.*;
class Board extends JPanel implements MouseListener
{  
        JFrame mainMenu;
        Container contain;
	Tile[][] tiles = new Tile[8][8];//the entire board.
	AI ai= null;
	Piece userPiece= null;
	Tile goal= null;
        int level;
	Board(int level)
	{
            this.level=level;
            ai= new AI();
            readLevel(level);
            addMouseListener(this);
	}	
        void setMainMenu(JFrame f)
        {
            this.mainMenu =f;
        }
        @Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		int count=0;
		for(int i=0;i<tiles.length;i++)
		{
			for(int j=0;j<tiles[i].length;j++)
			{
				count%=2;
				tiles[i][j].draw(g,count);
				count++;
			}
			count++; 
		}
	}
	void readLevel(int level)
	{
		//reads in a map for the current level. 
		Scanner sc= null;
		try{
                    File file = new File(System.getProperty("user.dir")+"/resources/map/level"+level+".txt");
                    sc = new Scanner(file);
		}catch(FileNotFoundException e){
                    e.printStackTrace();
                }
		
		int token= sc.nextInt();//player token.

		for(int i=0;sc.hasNextInt();i++)
		{
			for(int j=0;j<tiles[i].length;j++)
			{
				int temp = sc.nextInt();
				if(temp>3)//AI tile
				{
					tiles[j][i]= getPiece(j,i,temp,0);
					ai.addPiece((Piece)tiles[j][i]);
					//System.out.println(tiles[j][i]);
				}
				else if(temp==2)//0 is immovable, 1 is regular
				{
					userPiece= getPiece(j,i,token,1);
					tiles[j][i]= userPiece;
					//System.out.println(userPiece);
				}
				else 
				{
					if(temp==3)
					{
						goal= new Tile(j,i,temp);
						//System.out.println(goal);
					}
					tiles[j][i] = new Tile(j,i,temp);
				}
			}
		}
        userPiece.setGoal(goal);
        ai.addUser(userPiece);
	}
	
	//various listener methods.
	public Piece getPiece(int x, int y, int i, int color)
	{
		//i is greater than 3. 
		switch(i)
		{
			case(4):return(new Rook(x,y,4,color));
			case(5):return(new Knight(x,y,5,color));
			case(6):return(new Bishop(x,y,6,color));
			case(7):return(new Queen(x,y,7,color));
			case(8):return(new King(x,y,8,color));
		}
		return null;
	}
	public void mousePressed(MouseEvent e)
	{
		
		Tile moveLoc = null;
		outer: for(int i=0;i<tiles.length;i++)
		{
			for(int j=0;j<tiles[i].length;j++)
			{
				moveLoc = tiles[j][i].check(e);
				
				if(moveLoc!=null)
				{
					break outer;
				}
			}
		}
		Tile tempPiece = new Tile(userPiece);
        Tile[][] temp= userPiece.move(moveLoc,tiles,ai);
		if(!(userPiece.equals(tempPiece)))
		{
			tiles=temp;
			if(!ai.isEmpty())
			{
				ai.updateUser(userPiece);

				tiles= ai.decision(tiles);
                                repaint();
                                if(ai.getUser()==null)
                                {
                                    JOptionPane.showMessageDialog(null,"Game Over");
                                    
                                    //if they wish to restart re-read level. 
                                    //else close screen
                                }
                //ai.evaluatePaths(tiles,userPiece);
			}

		}
        for(int i=0;i<tiles.length;i++)
        {
            for(int j=0;j<tiles[i].length;j++)
            {
                System.out.print(tiles[j][i].getType()+ ", ");
            }
            System.out.println();
        }
		repaint();
	}
	public void mouseExited(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseClicked(MouseEvent e){}
}	
